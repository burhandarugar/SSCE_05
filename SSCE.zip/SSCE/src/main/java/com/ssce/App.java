package com.ssce;
import com.ssce.model.Employee;
import com.ssce.service.ServiceFunctions;
import com.ssce.service.ServiceImplementation;
import java.util.List;
import java.util.Scanner;

public class App
{
    public static void main( String[] args )
    {
        Employee employee;
        ServiceFunctions service = new ServiceImplementation();
        Scanner scan = new Scanner(System.in);
        int choice;
        do {
            System.out.println("1-Add 2-update 3-delete 4-find by ID 5-find All 6-exit");
            choice= scan.nextInt();
            switch(choice)
            {
                case 1: System.out.println("Enter Employee Details");
                        employee = new Employee(scan.nextInt(), scan.next(), scan.nextInt());
                        service.addEmployee(employee);
                        break;
                case 2: System.out.println("Enter Employee ID and Details");
                        int age = scan.nextInt();
                        employee = new Employee(scan.nextInt(), scan.next(), scan.nextInt());
                        service.updateEmployee(age,employee);
                        break;
                case 3: service.deleteEmployee(scan.nextInt());
                        break;
                case 4: System.out.println(service.findByEmployeeId(scan.nextInt()));
                        break;
                case 5: List<Employee> list =service.findAll();
                        for(Employee emp : list)
                        {
                            System.out.println(emp);
                        }
                        break;
                case 6:break;
            }
        }while(choice!=6);
        scan.close();

    }
}
