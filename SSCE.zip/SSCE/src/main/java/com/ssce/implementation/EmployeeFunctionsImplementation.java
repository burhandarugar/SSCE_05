package com.ssce.implementation;

import com.ssce.model.Employee;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class EmployeeFunctionsImplementation implements EmployeeFunctions
{
    private ArrayList<Employee> employees;
    public EmployeeFunctionsImplementation()
    {
        employees = new ArrayList<Employee>();
    }
    @Override
    public Employee addEmployee(Employee employee)
    {
        if(employees.add(employee))
            return employee;
        return null;
    }
    @Override
    public Employee updateEmployee(Integer employeeId,Employee employee)
    {
        Employee e;
        ListIterator<Employee> it = employees.listIterator();
        while(it.hasNext())
        {
            e=it.next();
            if(e.getEmployeeId().equals(employeeId))
            {
                it.set(employee);
                return employee;
            }
        }
        return null;
    }

    @Override
    public void deleteEmployee(Integer employeeId)
    {
        Employee e;
        ListIterator<Employee> it = employees.listIterator();
        while(it.hasNext())
        {
            e=it.next();
            if(e.getEmployeeId().equals(employeeId))
                it.remove();
        }
    }

    @Override
    public Employee findByEmployeeId(Integer employeeId)
    {
        Employee e;
        ListIterator<Employee> it = employees.listIterator();
        while(it.hasNext())
        {
            e=it.next();
            if(e.getEmployeeId().equals(employeeId))
                return e;
        }
        return null;
    }

    @Override
    public List<Employee> findAll()
    {
        return employees;
    }
}
