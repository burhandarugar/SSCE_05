package com.ssce.service;

import com.ssce.model.Employee;

import java.util.List;

public interface ServiceFunctions
{
    public Employee addEmployee(Employee employee);
    public Employee updateEmployee(Integer employeeId,Employee employee);
    public void deleteEmployee(Integer employeeId);
    public Employee findByEmployeeId(Integer employeeId);
    public List<Employee> findAll();
}
