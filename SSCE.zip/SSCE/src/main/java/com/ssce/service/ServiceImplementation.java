package com.ssce.service;
import com.ssce.implementation.EmployeeFunctionsImplementation;
import com.ssce.model.Employee;
import java.util.List;
public class ServiceImplementation implements ServiceFunctions
{
    EmployeeFunctionsImplementation employees;
    public ServiceImplementation()
    {
        employees = new EmployeeFunctionsImplementation();
    }

    @Override
    public Employee addEmployee(Employee employee)
    {
        return employees.addEmployee(employee);
    }

    @Override
    public Employee updateEmployee(Integer employeeId, Employee employee)
    {
        return employees.updateEmployee(employeeId,employee);
    }

    @Override
    public void deleteEmployee(Integer employeeId)
    {
        employees.deleteEmployee(employeeId);
    }

    @Override
    public Employee findByEmployeeId(Integer employeeId)
    {
        return employees.findByEmployeeId(employeeId);
    }

    @Override
    public List<Employee> findAll()
    {
        return employees.findAll();
    }
}
